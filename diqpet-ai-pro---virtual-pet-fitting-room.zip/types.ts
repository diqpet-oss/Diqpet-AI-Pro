
export interface ImageAssets {
  pet: string | null;
  clothing: string | null;
  result: string | null;
}
